#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>
#include "date.h"
using namespace std;

class Employee 
{
public:
	Employee(const string &,const string &,const string &, const Date &mon);
	void setFirstname(const string &);
	string getFirstname()const;
	
	void setLastname(const string &);
	string getLastname()const;

	void setSocialSecurityNumber(const string &);
	string getSocialSecurityNumber()const;

	static const int totalmonth=12;
	void setBirthday(const Date &);
 Date getBirthday()const;

	virtual double earnings()const=0;
	virtual void print()const;

	int bonus();

private:
	string firstname;
	string lastname;
	string socialsecuritynumber;
	Date birthday;
};
#endif