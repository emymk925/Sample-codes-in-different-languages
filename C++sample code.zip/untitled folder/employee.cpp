#include <iostream>
#include "employee.h"
#include "date.h"
using namespace std;

Employee::Employee(const string &first,const string &last,const string &ssn,const Date &mon)
{
	firstname=first;
	lastname=last;
	socialsecuritynumber=ssn;
	birthday=mon;
}

void Employee::setFirstname(const string &first)
{
	firstname=first;
}
string Employee::getFirstname() const
{
	return firstname;
}

void Employee::setLastname(const string &last)
{
	lastname=last;
}
string Employee::getLastname() const
{
	return lastname;
}
void Employee::setSocialSecurityNumber(const string &ssn)
{
	socialsecuritynumber=ssn;
}
string Employee::getSocialSecurityNumber() const
{
	return socialsecuritynumber;
}
void Employee::setBirthday(const Date &mon)
{
	birthday=mon;
}
Date Employee::getBirthday()const
{
	return birthday;
}
void Employee::print()const
{
	cout<<"Name: "<<getFirstname()<<" "<<getLastname()<<endl;
	cout<<"Social Security Number: "<<getSocialSecurityNumber()<<endl;
	cout<<"Date of Birth: "<<getBirthday()<<endl;
}