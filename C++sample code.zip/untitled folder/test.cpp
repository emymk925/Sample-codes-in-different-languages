#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "date.h"
#include "employee.h"
#include "salaried.h"
#include "hourly.h"
#include "commission.h"
#include "baseplus.h"
using namespace std;

void virtualViaPointer(const Employee*const);
int main()
{
	Date birthday(8,9,1990); 

	birthday.setDate(5,20,1990);
	SalariedEmployee SE("John", "Smith", "111-111-111", birthday, 800);
	
	birthday.setDate(9,4,1993);
	HourlyEmployee HE("Karen", "Prince", "222-22-2222", birthday, 16.75, 40);

	birthday.setDate(9,25,1993);
	CommissionEmployee CE("Sue", "Jones", "333-33-3333", birthday ,10000, 0.06);

	birthday.setDate(10,22,1996);
	BasePlusCommissionEmployee BE("Bob", "Lewis", "444-44-4444", birthday, 5000, 0.04, 300);

	cout<<"Employee processed individually using static binding: "<<endl;
	SE.print();
	cout<<"earned $"<<SE.earnings()<<endl;
	cout<<endl;

	HE.print();
	cout<<"earned $"<<HE.earnings()<<endl;
	cout<<endl;

	CE.print();
	cout<<"earned $"<<CE.earnings()<<endl;
	cout<<endl;
	
	BE.print();
	cout<<"earned $"<<BE.earnings()<<endl;
	cout<<endl;

	vector<Employee*>employees(4);
	employees[0]=&SE;
	employees[1]=&HE;
	employees[2]=&CE;
	employees[3]=&BE;

	cout<<"Employees processed polymorphically:";
		for(size_t i=0; i<employees.size(); ++i)
			{
				virtualViaPointer(employees[i]);
				if (employees[i]->getBirthday().getMonth() == 12)
				{
					cout<<"You have a bonus $100."<<endl;
				}
		}
		system ("pause");
		return 0;
}

void virtualViaPointer(const Employee*const baseClassPtr)
	{
		baseClassPtr->print();
		cout<<"earned $"<<baseClassPtr->earnings()<<endl;
	}