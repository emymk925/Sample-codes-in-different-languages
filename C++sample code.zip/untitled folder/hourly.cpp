#include <iostream>
#include <string>
#include "hourly.h"
using namespace std;

HourlyEmployee::HourlyEmployee(const string &first,const string &last,const string &ssn,const Date &mon,
	double hourlywage, double hoursworked):Employee(first, last, ssn, mon)
{
	setWage(hourlywage);
	setHours(hoursworked);
}

void HourlyEmployee::setWage(double hourlywage)
{//different from textbook, I write this for me to easier understand.
	if (hourlywage>=0.0)
		wage=hourlywage;
	else 
		throw invalid_argument("Hourly wage must be >=0");
}
double HourlyEmployee::getWage()const
{
	return wage;
}
void HourlyEmployee::setHours(double hoursworked)
{//different from textbook, I write this for me to easier understand.
	if (hoursworked>=0.0 && hoursworked<=hoursPerWeek)
		hours=hoursworked;
	else
		throw invalid_argument("Hours work must be >=0 and <= hours per week");
}
double HourlyEmployee::getHours()const
{
	return hours;
}
double HourlyEmployee::earnings() const
{
	if (getHours()<=40)
		return getWage()*getHours();
	else
		return 40*getWage()+((getHours()-40)*getWage()*1.5);
}
void HourlyEmployee::print()const
{
	cout<<"Hourly Employee ";
	Employee::print();
	cout<<"hourly wage: "<<getWage()<<". Hours worked: "<<getHours()<<endl;
}